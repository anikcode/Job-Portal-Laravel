@extends('layouts.app')
@section('content')

<!DOCTYPE html>
<html>
<head>
	<title>Send mail</title>
</head>
<body>

</body>
</html>