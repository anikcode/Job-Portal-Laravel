# Job-portal
![Screenshot (38)](https://user-images.githubusercontent.com/4586123/57188302-eea27300-6f19-11e9-9484-dbb66a8dc9ec.png)<br/>
</br>
This is project built during my internship using laravel framework. it is simple job portal in Laravel.This project has all the features that is needed by Admin,Company and Job seeker individual.
